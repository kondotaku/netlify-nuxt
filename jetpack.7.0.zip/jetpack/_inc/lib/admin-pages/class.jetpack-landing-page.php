<?php
// This is intentionally left empty as a stub because some sites were caching the require()
// @see https://github.com/Automattic/jetpack/issues/5091
